"use client";

import { TaskWorkspace } from "@/components/tasks/task-workspace";
import { useActorProfile } from "@/hooks/use-actor-profile";

export default function TasksPage() {
  const actor = useActorProfile();

  return (
    <main className="space-y-6">
      <section className="glass-panel rounded-[2rem] p-8">
        <p className="text-xs uppercase tracking-[0.28em] text-accent">Task Operations</p>
        <h1 className="mt-3 text-4xl font-semibold">Subsystem mission board</h1>
        <p className="mt-3 max-w-2xl text-muted">
          {actor.role} workspace for dependencies, priorities, deadlines, and subsystem ownership across engineering execution.
        </p>
      </section>

      <TaskWorkspace tasks={[]} />
    </main>
  );
}
